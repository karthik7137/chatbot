# -*- coding: utf-8 -*-
"""
Created on Tue May 15 23:28:25 2018

@author: Shashank
"""

map_keys = {
        'one':1,
        'first':1,
        'two':2,
        'second':2,
        'three':3,
        'third':3,
        'four':4,
        'fourth':4,
        'five':5,
        'fifth':5,
        'six':6,
        'sixth':6,
        'seven':7,
        'seventh':7,
        'eight':8,
        'eighth':8,
        'nine':9,
        'ninth':9,
        'zero':0,
        'zeroth':0
        }
if('2' in map_keys.keys()):
    print(map_keys['five'])
